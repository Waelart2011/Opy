import React, { useEffect, useState } from "react"
import { Dialog, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Switch } from "@/components/ui/switch"
import { useGetSettings, useUpdateSettings } from "@workspace/api-client-react"
import { useQueryClient } from "@tanstack/react-query"
import { toast } from "sonner"
import { Shield, Wifi, WifiOff, Globe, MonitorPlay, Moon, Sun, Zap, Copy, Check, ExternalLink } from "lucide-react"

const API_BASE = window.location.origin
const WEBHOOK_URL = `${API_BASE}/api/alexa/webhook`

export default function SettingsModal({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const { data: settings } = useGetSettings()
  const queryClient = useQueryClient()
  const [copied, setCopied] = useState(false)

  const updateSettings = useUpdateSettings({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/settings"] })
        toast.success("تم حفظ الإعدادات")
      }
    }
  })

  const [local, setLocal] = useState({
    offlineMode: true, language: "auto", allowCodeExecution: false, theme: "dark"
  })

  useEffect(() => {
    if (settings) setLocal(settings as any)
  }, [settings])

  const toggle = (key: keyof typeof local) => (checked: boolean) => {
    setLocal(p => ({ ...p, [key]: checked }))
    updateSettings.mutate({ data: { [key]: checked } })
  }

  const select = (key: keyof typeof local, value: string) => {
    setLocal(p => ({ ...p, [key]: value }))
    updateSettings.mutate({ data: { [key]: value } })
  }

  const copyWebhook = () => {
    navigator.clipboard.writeText(WEBHOOK_URL)
    setCopied(true)
    toast.success("✓ تم نسخ رابط الـ Webhook")
    setTimeout(() => setCopied(false), 2000)
  }

  const Row = ({ icon: Icon, iconColor, title, desc, children }: any) => (
    <div className="flex items-center justify-between p-4 bg-secondary/30 rounded-xl border border-border/50">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <div className={`p-2 bg-background rounded-lg ${iconColor}`}><Icon size={18} /></div>
        <div className="min-w-0">
          <h4 className="font-semibold text-foreground text-sm">{title}</h4>
          <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
        </div>
      </div>
      {children}
    </div>
  )

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogHeader>
        <DialogTitle>إعدادات Opy</DialogTitle>
      </DialogHeader>

      <div className="space-y-3 max-h-[70vh] overflow-y-auto pr-1">

        {/* Offline mode */}
        <Row icon={local.offlineMode ? WifiOff : Wifi} iconColor="text-primary"
          title="وضع عدم الاتصال"
          desc="يمنع Opy من الاتصال بالإنترنت تلقائياً (الافتراضي)">
          <Switch checked={local.offlineMode} onCheckedChange={toggle("offlineMode")} />
        </Row>

        {/* Code execution */}
        <Row icon={MonitorPlay} iconColor="text-emerald-500"
          title="تنفيذ الكود"
          desc="السماح لـ Opy بتشغيل أكواد برمجية داخلياً">
          <Switch checked={local.allowCodeExecution} onCheckedChange={toggle("allowCodeExecution")} />
        </Row>

        {/* Language */}
        <div className="p-4 bg-secondary/30 rounded-xl border border-border/50 space-y-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-background rounded-lg text-orange-400"><Globe size={18} /></div>
            <div>
              <h4 className="font-semibold text-foreground text-sm">اللغة</h4>
              <p className="text-xs text-muted-foreground">لغة الردود المفضلة</p>
            </div>
          </div>
          <div className="flex gap-2 bg-background p-1 rounded-lg border border-border/40">
            {[["auto", "تلقائي"], ["ar", "العربية"], ["en", "English"]].map(([v, l]) => (
              <button key={v} onClick={() => select("language", v)}
                className={`flex-1 py-1.5 rounded-md text-xs font-medium transition-all
                  ${local.language === v ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:bg-secondary"}`}
              >{l}</button>
            ))}
          </div>
        </div>

        {/* Theme */}
        <div className="p-4 bg-secondary/30 rounded-xl border border-border/50 space-y-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-background rounded-lg text-indigo-400">
              {local.theme === "dark" ? <Moon size={18} /> : <Sun size={18} />}
            </div>
            <div>
              <h4 className="font-semibold text-foreground text-sm">المظهر</h4>
              <p className="text-xs text-muted-foreground">مظهر التطبيق</p>
            </div>
          </div>
          <div className="flex gap-2 bg-background p-1 rounded-lg border border-border/40">
            {[["dark", "داكن"], ["light", "فاتح"], ["system", "النظام"]].map(([v, l]) => (
              <button key={v} onClick={() => select("theme", v)}
                className={`flex-1 py-1.5 rounded-md text-xs font-medium transition-all
                  ${local.theme === v ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:bg-secondary"}`}
              >{l}</button>
            ))}
          </div>
        </div>

        {/* Alexa / Smart Home */}
        <div className="p-4 bg-secondary/30 rounded-xl border border-border/50 space-y-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-background rounded-lg text-cyan-400"><Zap size={18} /></div>
            <div>
              <h4 className="font-semibold text-foreground text-sm">ربط الأجهزة الذكية</h4>
              <p className="text-xs text-muted-foreground">Alexa · Google Home · IFTTT</p>
            </div>
          </div>

          <div className="bg-background/50 rounded-xl p-3 border border-border/30">
            <p className="text-[11px] font-bold text-muted-foreground/70 mb-1.5 uppercase tracking-wider">رابط الـ Webhook</p>
            <div className="flex items-center gap-2">
              <code className="flex-1 text-[11px] text-primary font-mono bg-muted/40 px-2 py-1 rounded-lg truncate">
                {WEBHOOK_URL}
              </code>
              <button onClick={copyWebhook}
                className="p-1.5 rounded-lg bg-primary/10 hover:bg-primary/20 text-primary transition-all">
                {copied ? <Check size={13} /> : <Copy size={13} />}
              </button>
            </div>
          </div>

          <div className="space-y-2 text-right" dir="rtl">
            <p className="text-[11px] font-bold text-muted-foreground/70">خطوات الربط مع Alexa:</p>
            {[
              "افتح Alexa Developer Console",
              "أنشئ Custom Skill جديد",
              "في Endpoint اختر HTTPS والصق الرابط أعلاه",
              "أضف Intent باسم OPY_QUERY بـ slot اسمه query",
            ].map((s, i) => (
              <div key={i} className="flex items-start gap-2 text-[11px] text-muted-foreground">
                <span className="shrink-0 w-4 h-4 rounded-full bg-primary/20 text-primary flex items-center justify-center text-[9px] font-bold mt-0.5">{i + 1}</span>
                {s}
              </div>
            ))}
            <p className="text-[11px] font-bold text-muted-foreground/70 mt-3">لـ IFTTT / Google Home:</p>
            <p className="text-[11px] text-muted-foreground">
              في IFTTT اختر Webhooks → Make web request → Method: POST → Body: {"{ \"query\": \"{{TextField}}\" }"}
            </p>
          </div>
        </div>

        {/* Security info */}
        <div className="flex items-center gap-3 p-4 bg-emerald-500/5 rounded-xl border border-emerald-500/20">
          <Shield size={18} className="text-emerald-400 shrink-0" />
          <p className="text-xs text-muted-foreground leading-relaxed">
            Opy لا يتخذ أي إجراء بدون موافقتك الصريحة. جميع البيانات محفوظة محلياً.
          </p>
        </div>
      </div>
    </Dialog>
  )
}
