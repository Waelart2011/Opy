import React, { useState, useRef } from "react"
import { Link, useLocation } from "wouter"
import {
  MessageSquare, Image as ImageIcon, Video,
  FileText, Search, Settings, Shield, Plus, Trash2,
  WifiOff, Wifi, BrainCircuit, BookMarked, Code2,
  Clipboard, Maximize2, Bell, Camera, MapPin,
  ChevronRight, Zap, Cpu, X, Menu
} from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { useGetChatSessions, useCreateChatSession, useDeleteChatSession, useGetSettings } from "@workspace/api-client-react"
import { useQueryClient } from "@tanstack/react-query"
import SettingsModal from "@/components/settings/SettingsModal"
import { toast } from "sonner"

/* ══════════════ Device Control Panel ══════════════ */
function DevicePanel({ onClose }: { onClose: () => void }) {
  const [status, setStatus] = useState<Record<string, boolean>>({})

  const run = async (action: string, fn: () => Promise<any>) => {
    try {
      await fn()
      setStatus(s => ({ ...s, [action]: true }))
      setTimeout(() => setStatus(s => ({ ...s, [action]: false })), 2000)
    } catch (e: any) {
      toast.error(e?.message || `${action} فشل`)
    }
  }

  const controls = [
    {
      label: "نسخ للحافظة", icon: Clipboard,
      action: () => run("clipboard", async () => {
        await navigator.clipboard.writeText("Opy — مساعدك الذكي")
        toast.success("✓ نُسخ إلى الحافظة")
      })
    },
    {
      label: "ملء الشاشة", icon: Maximize2,
      action: () => run("fullscreen", async () => {
        if (!document.fullscreenElement) await document.documentElement.requestFullscreen()
        else await document.exitFullscreen()
        toast.success(document.fullscreenElement ? "✓ ملء الشاشة" : "✓ تم الخروج")
      })
    },
    {
      label: "إشعار تجريبي", icon: Bell,
      action: () => run("notify", async () => {
        const perm = await Notification.requestPermission()
        if (perm === "granted") new Notification("Opy", { body: "أنا هنا وجاهز! 🤖", icon: "/images/opy-logo.png" })
        else toast.error("الإذن مرفوض")
      })
    },
    {
      label: "تصوير الشاشة", icon: Camera,
      action: () => run("screenshot", async () => {
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true })
        const track = stream.getVideoTracks()[0]
        const imageCapture = new (window as any).ImageCapture(track)
        const bitmap = await imageCapture.grabFrame()
        track.stop()
        const canvas = document.createElement("canvas")
        canvas.width = bitmap.width; canvas.height = bitmap.height
        const ctx = canvas.getContext("2d")!
        ctx.drawImage(bitmap, 0, 0)
        canvas.toBlob(b => {
          const a = document.createElement("a")
          a.href = URL.createObjectURL(b!)
          a.download = `opy-screenshot-${Date.now()}.png`
          a.click()
        })
        toast.success("✓ تم تصوير الشاشة وحفظها")
      })
    },
    {
      label: "موقعي الجغرافي", icon: MapPin,
      action: () => run("geo", async () => {
        const pos = await new Promise<GeolocationPosition>((res, rej) =>
          navigator.geolocation.getCurrentPosition(res, rej)
        )
        toast.success(`📍 ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`)
      })
    },
    {
      label: "منع وضع النوم", icon: Zap,
      action: () => run("wakelock", async () => {
        const lock = await (navigator as any).wakeLock?.request("screen")
        toast.success(lock ? "✓ وضع النوم معطّل" : "غير مدعوم")
      })
    },
  ]

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 8 }}
      className="absolute bottom-14 left-2 right-2 glass-card rounded-2xl p-4 z-50 shadow-2xl border border-primary/20"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Cpu size={14} className="text-primary" />
          <span className="text-sm font-bold text-foreground">تحكم بالجهاز</span>
        </div>
        <button onClick={onClose} className="p-1 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-all">
          <X size={13} />
        </button>
      </div>
      <div className="grid grid-cols-2 gap-1.5">
        {controls.map(c => (
          <button key={c.label} onClick={c.action}
            className="flex items-center gap-2 px-3 py-2 rounded-xl bg-secondary/60 hover:bg-secondary border border-border/40 hover:border-primary/30 text-xs text-muted-foreground hover:text-foreground transition-all text-right">
            <c.icon size={13} className="text-primary shrink-0" />
            <span className="truncate">{c.label}</span>
          </button>
        ))}
      </div>
      <p className="text-[10px] text-muted-foreground/50 text-center mt-2">
        يعمل في المتصفح · بعض الميزات تحتاج إذن
      </p>
    </motion.div>
  )
}

/* ══════════════ SIDEBAR CONTENT ══════════════ */
function SidebarContent({
  sessions, location, isOnline,
  onNewChat, onDelete, onSettings, onCloseMobile
}: any) {
  const [deviceOpen, setDeviceOpen] = useState(false)

  const NavItem = ({ href, icon: Icon, label }: { href: string; icon: any; label: string }) => {
    const active = href !== "/" ? location.startsWith(href) : location === "/"
    return (
      <Link href={href} onClick={onCloseMobile}>
        <div className={`flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer transition-all duration-150 group relative
          ${active ? "bg-primary/12 text-primary" : "hover:bg-secondary/50 text-muted-foreground hover:text-foreground"}`}>
          {active && <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-primary rounded-r-full" />}
          <Icon size={17} className={active ? "text-primary" : "group-hover:text-foreground transition-colors"} />
          <span className="font-medium text-sm flex-1">{label}</span>
          {active && <ChevronRight size={13} className="opacity-50" />}
        </div>
      </Link>
    )
  }

  return (
    <div className="flex flex-col h-full bg-card border-r border-border/40 relative">
      {/* Logo */}
      <div className="flex-shrink-0 p-5 border-b border-border/30">
        <Link href="/">
          <div className="flex items-center gap-3 cursor-pointer group">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary/90 to-accent/40 flex items-center justify-center shadow-[0_0_16px_-4px_var(--glow-primary)] group-hover:shadow-[0_0_24px_-4px_var(--glow-primary)] transition-all">
              <BrainCircuit size={20} className="text-background" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-foreground leading-none">Opy</h1>
              <span className="text-[9px] uppercase tracking-widest text-primary font-bold">Personal AI</span>
            </div>
          </div>
        </Link>
      </div>

      {/* New Chat */}
      <div className="flex-shrink-0 px-3 pt-3 pb-1">
        <button onClick={onNewChat}
          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-bold text-sm hover:bg-primary/90 transition-all shadow-[0_0_16px_-6px_var(--glow-primary)]">
          <Plus size={16} /> محادثة جديدة
        </button>
      </div>

      {/* Nav */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-0.5 min-h-0">
        <p className="px-3 pt-2 pb-1.5 text-[10px] font-bold text-muted-foreground/50 uppercase tracking-widest">الأدوات</p>
        <NavItem href="/tools/memory" icon={Search} label="بحث الذاكرة" />
        <NavItem href="/tools/knowledge" icon={BookMarked} label="قاعدة المعرفة" />
        <NavItem href="/tools/image" icon={ImageIcon} label="توليد الصور" />
        <NavItem href="/tools/video" icon={Video} label="إنشاء الفيديو" />
        <NavItem href="/tools/document" icon={FileText} label="المستندات" />
        <NavItem href="/tools/self" icon={Code2} label="تطوير Opy" />

        <p className="px-3 pt-4 pb-1.5 text-[10px] font-bold text-muted-foreground/50 uppercase tracking-widest">المحادثات</p>
        {sessions.length === 0 && (
          <p className="px-3 py-2 text-xs text-muted-foreground/40 italic">لا توجد محادثات بعد</p>
        )}
        {sessions.map((s: any) => (
          <div key={s.id} className="relative group">
            <Link href={`/session/${s.id}`} onClick={onCloseMobile}>
              <div className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl cursor-pointer transition-all
                ${location === `/session/${s.id}` ? "bg-secondary text-foreground" : "hover:bg-secondary/40 text-muted-foreground hover:text-foreground"}`}>
                <MessageSquare size={13} className="shrink-0" />
                <span className="text-sm truncate flex-1 font-medium" dir="auto">{s.title}</span>
              </div>
            </Link>
            <button
              onClick={(e) => { e.preventDefault(); e.stopPropagation(); onDelete(s.id) }}
              className="absolute left-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 p-1 text-muted-foreground/50 hover:text-destructive transition-all">
              <Trash2 size={11} />
            </button>
          </div>
        ))}
      </div>

      {/* Bottom bar — always visible ── */}
      <div className="flex-shrink-0 border-t border-border/30 p-3 space-y-1 relative">
        {/* Online/offline badge */}
        <div className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold border
          ${isOnline ? "bg-orange-500/10 text-orange-400 border-orange-500/25" : "bg-primary/10 text-primary border-primary/25"}`}>
          {isOnline ? <Wifi size={13} /> : <WifiOff size={13} />}
          <span>{isOnline ? "وضع متصل" : "وضع غير متصل (افتراضي)"}</span>
          <Shield size={12} className="ml-auto text-emerald-400" />
        </div>

        {/* Device control */}
        <button onClick={() => setDeviceOpen(o => !o)}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-secondary/60 text-muted-foreground hover:text-foreground transition-all border border-transparent hover:border-border/40">
          <Cpu size={17} />
          <span className="text-sm font-medium">تحكم بالجهاز</span>
        </button>

        {/* Settings */}
        <button onClick={onSettings}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-secondary/60 text-muted-foreground hover:text-foreground transition-all">
          <Settings size={17} />
          <span className="text-sm font-medium">الإعدادات</span>
        </button>

        {/* Device panel popup */}
        <AnimatePresence>
          {deviceOpen && <DevicePanel onClose={() => setDeviceOpen(false)} />}
        </AnimatePresence>
      </div>
    </div>
  )
}

/* ══════════════ LAYOUT ══════════════ */
export default function AppLayout({ children }: { children: React.ReactNode }) {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [location, setLocation] = useLocation()
  const queryClient = useQueryClient()

  const { data: sessions = [] } = useGetChatSessions()
  const { data: settings } = useGetSettings()

  const createSession = useCreateChatSession({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: ["/api/chat/sessions"] })
        setLocation(`/session/${data.id}`)
        setMobileSidebarOpen(false)
      }
    }
  })

  const deleteSession = useDeleteChatSession({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/chat/sessions"] })
        setLocation("/")
        toast.success("تم حذف المحادثة")
      }
    }
  })

  const sharedProps = {
    sessions,
    location,
    isOnline: settings?.offlineMode === false,
    onNewChat: () => createSession.mutate({ data: { title: "محادثة جديدة" } }),
    onDelete: (id: string) => { if (confirm("حذف هذه المحادثة؟")) deleteSession.mutate({ sessionId: id }) },
    onSettings: () => setSettingsOpen(true),
    onCloseMobile: () => setMobileSidebarOpen(false),
  }

  const pageTitle = location === "/" ? "الرئيسية"
    : location.includes("/session/") ? "محادثة"
    : location.includes("/tools/memory") ? "بحث الذاكرة"
    : location.includes("/tools/knowledge") ? "قاعدة المعرفة"
    : location.includes("/tools/image") ? "توليد الصور"
    : location.includes("/tools/video") ? "إنشاء الفيديو"
    : location.includes("/tools/document") ? "المستندات"
    : location.includes("/tools/self") ? "تطوير Opy"
    : "Opy"

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">

      {/* ── MOBILE sidebar overlay ── */}
      <AnimatePresence>
        {mobileSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setMobileSidebarOpen(false)}
              className="fixed inset-0 z-40 bg-background/70 backdrop-blur-sm md:hidden" />
            <motion.div
              initial={{ x: "-100%" }} animate={{ x: 0 }} exit={{ x: "-100%" }}
              transition={{ type: "spring", bounce: 0, duration: 0.26 }}
              className="fixed inset-y-0 left-0 z-50 w-72 md:hidden shadow-2xl">
              <div className="h-full relative">
                <button onClick={() => setMobileSidebarOpen(false)}
                  className="absolute top-4 right-4 z-10 p-1.5 rounded-lg hover:bg-secondary text-muted-foreground">
                  <X size={18} />
                </button>
                <SidebarContent {...sharedProps} />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ── DESKTOP sidebar — always visible, never hides ── */}
      <div className="hidden md:flex md:w-[260px] shrink-0 flex-col h-full z-10 shadow-[1px_0_0_hsl(var(--border)/0.4)]">
        <SidebarContent {...sharedProps} />
      </div>

      {/* ── Main content ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile header */}
        <header className="md:hidden flex-shrink-0 h-14 glass-card border-x-0 border-t-0 flex items-center justify-between px-4 z-10">
          <button onClick={() => setMobileSidebarOpen(true)} className="p-1.5 text-foreground hover:text-primary transition-colors">
            <Menu size={22} />
          </button>
          <span className="font-bold text-foreground">{pageTitle}</span>
          <div className="w-8" />
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-hidden">
          {children}
        </main>
      </div>

      <SettingsModal open={settingsOpen} onOpenChange={setSettingsOpen} />
    </div>
  )
}
