import { Switch, Route, Router as WouterRouter } from "wouter"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { Toaster } from "sonner"
import AppLayout from "@/components/layout/AppLayout"

import Welcome from "@/pages/Welcome"
import ChatSession from "@/pages/ChatSession"
import ToolImage from "@/pages/ToolImage"
import ToolVideo from "@/pages/ToolVideo"
import ToolDocument from "@/pages/ToolDocument"
import ToolMemory from "@/pages/ToolMemory"
import ToolKnowledge from "@/pages/ToolKnowledge"
import ToolSelf from "@/pages/ToolSelf"
import NotFound from "@/pages/not-found"

const queryClient = new QueryClient({
  defaultOptions: { queries: { refetchOnWindowFocus: false, staleTime: 5 * 60 * 1000 } },
})

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Welcome} />
        <Route path="/session/:id" component={ChatSession} />
        <Route path="/tools/image" component={ToolImage} />
        <Route path="/tools/video" component={ToolVideo} />
        <Route path="/tools/document" component={ToolDocument} />
        <Route path="/tools/memory" component={ToolMemory} />
        <Route path="/tools/knowledge" component={ToolKnowledge} />
        <Route path="/tools/self" component={ToolSelf} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  )
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <Router />
      </WouterRouter>
      <Toaster theme="dark" position="bottom-right" richColors />
    </QueryClientProvider>
  )
}
