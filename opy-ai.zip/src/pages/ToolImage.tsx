import React, { useState } from "react"
import { useGenerateImage } from "@workspace/api-client-react"
import { Image as ImageIcon, Loader2, Download, Wand2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { motion } from "framer-motion"

export default function ToolImage() {
  const [prompt, setPrompt] = useState("")
  const [style, setStyle] = useState<"geometric" | "gradient" | "pattern" | "abstract">("geometric")
  
  const generateImage = useGenerateImage()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim()) return
    generateImage.mutate({ data: { prompt, style, width: 512, height: 512 } })
  }

  return (
    <div className="h-full overflow-y-auto p-6 md:p-12 custom-scrollbar">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-primary/20 flex items-center justify-center text-primary border border-primary/30">
            <ImageIcon size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">Image Synthesis</h1>
            <p className="text-muted-foreground text-sm">Internal algorithmic generation without external APIs.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-5 space-y-6">
            <form onSubmit={handleSubmit} className="space-y-6 glass-panel p-6 rounded-2xl">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-foreground">Mathematical Description</label>
                <Textarea 
                  placeholder="Describe shapes, colors, and layout..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="min-h-[120px]"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-foreground">Algorithm Style</label>
                <div className="grid grid-cols-2 gap-2">
                  {(["geometric", "gradient", "pattern", "abstract"] as const).map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setStyle(s)}
                      className={`py-2 px-3 rounded-lg text-sm font-medium capitalize border transition-all ${style === s ? 'bg-primary text-primary-foreground border-primary' : 'bg-background border-border text-muted-foreground hover:bg-secondary'}`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <Button type="submit" className="w-full" variant="glow" disabled={!prompt.trim() || generateImage.isPending}>
                {generateImage.isPending ? (
                  <><Loader2 className="mr-2 animate-spin" size={18} /> Processing Matrix...</>
                ) : (
                  <><Wand2 className="mr-2" size={18} /> Generate Matrix</>
                )}
              </Button>
            </form>
          </div>

          <div className="lg:col-span-7">
            <div className="glass-panel p-2 rounded-2xl aspect-square flex flex-col items-center justify-center relative overflow-hidden bg-background">
              {generateImage.isPending ? (
                <div className="flex flex-col items-center gap-4 text-primary">
                  <div className="w-16 h-16 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                  <span className="font-mono text-sm uppercase tracking-widest animate-pulse">Rendering Pixel Array...</span>
                </div>
              ) : generateImage.isSuccess && generateImage.data ? (
                <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="w-full h-full relative group">
                  <img src={generateImage.data.dataUrl} alt={generateImage.data.prompt} className="w-full h-full object-cover rounded-xl" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-xl">
                    <a href={generateImage.data.dataUrl} download="opy-generated.png">
                      <Button variant="secondary"><Download className="mr-2" size={16} /> Download Source</Button>
                    </a>
                  </div>
                </motion.div>
              ) : (
                <div className="text-muted-foreground flex flex-col items-center gap-2">
                  <ImageIcon size={48} className="opacity-20" />
                  <span className="text-sm font-medium">Output frame ready</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
