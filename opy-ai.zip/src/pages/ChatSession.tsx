import React, { useState, useRef, useEffect, useCallback } from "react"
import { useRoute } from "wouter"
import { motion, AnimatePresence } from "framer-motion"
import ReactMarkdown from "react-markdown"
import remarkGfm from "remark-gfm"
import {
  Send, StopCircle, Copy, Check, Download, Mic,
  Volume2, VolumeX, Brain, User, Sparkles, Loader2, BookOpen
} from "lucide-react"
import { useGetChatHistory, useGetSettings } from "@workspace/api-client-react"
import { useQueryClient } from "@tanstack/react-query"
import { toast } from "sonner"
import type { ChatMessage } from "@workspace/api-client-react"

const API_BASE = window.location.origin

function getDir(text: string): "rtl" | "ltr" {
  return /[\u0600-\u06FF]/.test(text?.slice(0, 80) ?? "") ? "rtl" : "ltr"
}

/* ── Wave animation ── */
const WaveAnim = ({ active }: { active: boolean }) => (
  <div className="flex items-end gap-0.5 h-5 px-0.5">
    {[0, 0.1, 0.2, 0.3, 0.4].map((d, i) => (
      <div key={i} className={`wave-bar transition-all ${active ? "" : "!h-1 opacity-40"}`}
        style={{ animationDelay: `${d}s` }} />
    ))}
  </div>
)

/* ── Code block with copy button ── */
const CodeBlock = ({ children, className }: { children?: React.ReactNode; className?: string }) => {
  const [copied, setCopied] = useState(false)
  const lang = className?.replace("language-", "") ?? "code"
  const text = String(children).replace(/\n$/, "")

  const copy = () => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    toast.success("✓ تم نسخ الكود")
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="relative group my-3 rounded-xl overflow-hidden border border-border/60">
      <div className="flex items-center justify-between px-4 py-1.5 bg-secondary/60 border-b border-border/40">
        <span className="text-[11px] font-mono text-muted-foreground/70 uppercase tracking-wider">{lang}</span>
        <button onClick={copy}
          className="flex items-center gap-1.5 text-[11px] text-muted-foreground hover:text-foreground transition-all px-2 py-0.5 rounded-md hover:bg-secondary">
          {copied ? <Check size={11} className="text-primary" /> : <Copy size={11} />}
          {copied ? "نُسخ" : "نسخ"}
        </button>
      </div>
      <pre className="p-4 overflow-x-auto bg-muted/30 text-sm font-mono leading-relaxed m-0 rounded-none">
        <code>{text}</code>
      </pre>
    </div>
  )
}

/* ── Message bubble ── */
function MsgBubble({
  msg, onSpeak, speakingId
}: {
  msg: ChatMessage; onSpeak(t: string, id: string): void; speakingId: string | null
}) {
  const [copied, setCopied] = useState(false)
  const isAI = msg.role === "assistant"
  const dir = getDir(msg.content)
  const speaking = speakingId === msg.id

  const copy = () => {
    navigator.clipboard.writeText(msg.content)
    setCopied(true)
    toast.success(dir === "rtl" ? "✓ تم النسخ" : "✓ Copied")
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex gap-3 group ${isAI ? "" : "flex-row-reverse"}`}
    >
      <div className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center ring-2 mt-0.5
        ${isAI ? "bg-primary/10 ring-primary/25 text-primary" : "bg-accent/10 ring-accent/25 text-accent"}`}>
        {isAI ? <Brain size={14} /> : <User size={14} />}
      </div>

      <div className="relative max-w-[85%] min-w-0">
        <div className={`rounded-2xl px-4 py-3 text-sm leading-relaxed
          ${isAI ? "ai-bubble rounded-tl-sm" : "user-bubble rounded-tr-sm"}`}
          dir={dir}
        >
          {isAI ? (
            <div className="prose-chat">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  code({ node, className, children, ...props }: any) {
                    const isBlock = /language-/.test(className || "")
                    if (isBlock) return <CodeBlock className={className}>{children}</CodeBlock>
                    return <code className="bg-muted px-1.5 py-0.5 rounded-md text-primary text-[0.8em] font-mono" {...props}>{children}</code>
                  },
                  pre({ children }: any) { return <>{children}</> },
                }}
              >{msg.content}</ReactMarkdown>
            </div>
          ) : (
            <p className="whitespace-pre-wrap">{msg.content}</p>
          )}
        </div>

        {/* Hover actions */}
        <div className={`absolute -bottom-6 ${isAI ? "left-0" : "right-0"}
          flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all z-10`}>
          <button onClick={copy}
            className="p-1 rounded-md bg-card/95 hover:bg-secondary border border-border/50 text-muted-foreground hover:text-foreground transition-all"
            title="نسخ الرسالة">
            {copied ? <Check size={11} className="text-primary" /> : <Copy size={11} />}
          </button>
          {isAI && (
            <button onClick={() => onSpeak(msg.content, msg.id)}
              className={`p-1 rounded-md border transition-all
                ${speaking ? "bg-primary/20 border-primary/40 text-primary" : "bg-card/95 hover:bg-secondary border-border/50 text-muted-foreground hover:text-foreground"}`}
              title={speaking ? "إيقاف" : "قراءة بصوت Jarvis"}>
              {speaking ? <VolumeX size={11} /> : <Volume2 size={11} />}
            </button>
          )}
        </div>
      </div>
    </motion.div>
  )
}

/* ═══════════ MAIN ═══════════ */
export default function ChatSession() {
  const [, params] = useRoute("/session/:id")
  const sessionId = params?.id ?? ""

  const [input, setInput] = useState("")
  const [streaming, setStreaming] = useState(false)
  const [streamText, setStreamText] = useState("")
  const abortRef = useRef<AbortController | null>(null)

  const [speakingId, setSpeakingId] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const [isRecording, setIsRecording] = useState(false)
  const [isTranscribing, setIsTranscribing] = useState(false)
  const mediaRecRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const isAtBottomRef = useRef(true)
  const queryClient = useQueryClient()

  const { data: messages = [] } = useGetChatHistory(
    { sessionId, limit: 100 },
    { query: { refetchInterval: streaming ? false : 5000 } }
  )
  const { data: settings } = useGetSettings()

  /* ── Smart auto-scroll: only if user is near bottom ── */
  const checkIfAtBottom = () => {
    const el = scrollContainerRef.current
    if (!el) return true
    return el.scrollHeight - el.scrollTop - el.clientHeight < 120
  }

  const scrollToBottom = (force = false) => {
    if (force || isAtBottomRef.current) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
    }
  }

  useEffect(() => {
    const el = scrollContainerRef.current
    if (!el) return
    const handler = () => { isAtBottomRef.current = checkIfAtBottom() }
    el.addEventListener("scroll", handler, { passive: true })
    return () => el.removeEventListener("scroll", handler)
  }, [])

  useEffect(() => { scrollToBottom() }, [messages])
  useEffect(() => { scrollToBottom() }, [streamText])

  /* textarea resize */
  useEffect(() => {
    if (!textareaRef.current) return
    textareaRef.current.style.height = "auto"
    textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 160) + "px"
  }, [input])

  /* ── Send message ── */
  const send = useCallback(async () => {
    const text = input.trim()
    if (!text || streaming) return
    setInput(""); setStreamText(""); setStreaming(true)
    isAtBottomRef.current = true
    scrollToBottom(true)

    /* auto-learn */
    if (/^(تعلم|احفظ|تذكر|learn this|remember|save this)[:：\s]/i.test(text)) {
      const payload = text.replace(/^[^:：\s]+[:：\s]/, "").trim()
      if (payload) fetch(`${API_BASE}/api/learn`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: payload, source: "chat" }),
      }).catch(() => {})
    }

    /* self-modification intent */
    if (/^(عدّل|طور|أضف|احذف|modify opy|edit opy|update opy)\s/i.test(text)) {
      toast.info("🔧 جاري تحليل طلب التعديل على كود Opy...")
    }

    const ctrl = new AbortController()
    abortRef.current = ctrl
    try {
      const res = await fetch(`${API_BASE}/api/chat/messages/stream`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, content: text, allowInternet: settings?.offlineMode === false }),
        signal: ctrl.signal,
      })
      if (!res.ok) throw new Error()
      const reader = res.body!.getReader()
      const dec = new TextDecoder()
      let acc = ""
      loop: while (true) {
        const { done, value } = await reader.read()
        if (done) break
        for (const line of dec.decode(value, { stream: true }).split("\n")) {
          if (!line.startsWith("data: ")) continue
          try {
            const d = JSON.parse(line.slice(6))
            if (d.done) break loop
            if (d.content) { acc += d.content; setStreamText(acc) }
          } catch {}
        }
      }
    } catch (e: any) {
      if (e?.name !== "AbortError") toast.error("خطأ في الاتصال — حاول مرة أخرى")
    } finally {
      setStreaming(false); setStreamText(""); abortRef.current = null
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages"] })
    }
  }, [input, streaming, sessionId, settings, queryClient])

  /* ── TTS (Jarvis) ── */
  const speak = useCallback(async (text: string, id: string) => {
    if (speakingId === id) {
      audioRef.current?.pause()
      setSpeakingId(null); audioRef.current = null; return
    }
    audioRef.current?.pause(); setSpeakingId(id)
    try {
      const res = await fetch(`${API_BASE}/api/voice/tts`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: text.replace(/[#*`_~]/g, "").slice(0, 2000), voice: "onyx" }),
      })
      if (!res.ok) throw new Error()
      const url = URL.createObjectURL(await res.blob())
      const a = new Audio(url)
      audioRef.current = a; a.play()
      a.onended = () => { setSpeakingId(null); audioRef.current = null; URL.revokeObjectURL(url) }
    } catch { toast.error("الصوت غير متاح"); setSpeakingId(null) }
  }, [speakingId])

  /* ── STT (hold to talk) ── */
  const startRec = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mr = new MediaRecorder(stream, { mimeType: "audio/webm" })
      chunksRef.current = []
      mr.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data) }
      mr.onstop = async () => {
        stream.getTracks().forEach(t => t.stop())
        setIsTranscribing(true)
        try {
          const fd = new FormData()
          fd.append("audio", new Blob(chunksRef.current, { type: "audio/webm" }), "rec.webm")
          const r = await fetch(`${API_BASE}/api/voice/stt`, { method: "POST", body: fd })
          const d = await r.json()
          if (d.transcript) setInput(p => p ? p + " " + d.transcript : d.transcript)
        } catch { toast.error("لم يتم التعرف على الصوت") }
        finally { setIsTranscribing(false) }
      }
      mr.start(); mediaRecRef.current = mr; setIsRecording(true)
    } catch { toast.error("تعذّر الوصول للميكروفون") }
  }
  const stopRec = () => { mediaRecRef.current?.stop(); setIsRecording(false) }

  /* ── Download conversation ── */
  const download = () => {
    const lines = messages.map(m =>
      `**${m.role === "assistant" ? "Opy" : "أنت"}**:\n${m.content}`
    ).join("\n\n---\n\n")
    const a = Object.assign(document.createElement("a"), {
      href: URL.createObjectURL(new Blob([`# محادثة Opy\n\n${lines}`], { type: "text/markdown" })),
      download: `opy-${sessionId.slice(0, 8)}.md`
    })
    a.click(); toast.success("✓ تم تنزيل المحادثة")
  }

  /* ── Learn from chat ── */
  const learnChat = async () => {
    try {
      const r = await fetch(`${API_BASE}/api/learn/extract`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: messages.map(m => m.content).join("\n") }),
      })
      const d = await r.json()
      toast.success(d.count > 0 ? `✅ تعلمت ${d.count} معلومة جديدة!` : "لم أجد معلومات جديدة")
    } catch { toast.error("فشل التعلم") }
  }

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send() }
  }

  const suggestions = [
    "اشرح الذكاء الاصطناعي",
    "اكتب كود Python لقائمة مهام",
    "ساعدني في كتابة ايميل",
    "التقط لقطة شاشة",
    "افتح وضع ملء الشاشة",
  ]

  return (
    <div className="h-full flex flex-col bg-background">

      {/* ── top bar ── */}
      <div className="flex-shrink-0 h-12 glass-card border-x-0 border-t-0 flex items-center justify-between px-4">
        <div className="flex items-center gap-2 text-sm">
          <Brain size={15} className="text-primary" />
          <span className="font-semibold text-foreground">Opy</span>
          {streaming && (
            <span className="flex items-center gap-1.5 text-xs text-primary animate-pulse">
              <Loader2 size={11} className="animate-spin" /> يفكر...
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <button onClick={download} disabled={!messages.length}
            className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-all disabled:opacity-30"
            title="تنزيل المحادثة"><Download size={15} /></button>
          <button onClick={learnChat} disabled={!messages.length}
            className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-primary transition-all disabled:opacity-30"
            title="تعلم من المحادثة"><BookOpen size={15} /></button>
        </div>
      </div>

      {/* ── messages — scrollable independently ── */}
      <div ref={scrollContainerRef} className="flex-1 overflow-y-auto px-4 py-6">
        <div className="max-w-3xl mx-auto space-y-8">

          {messages.length === 0 && !streaming && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              className="flex flex-col items-center justify-center py-24 text-center gap-5">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center ring-1 ring-primary/20 shadow-[0_0_30px_-8px_var(--glow-primary)]">
                <Sparkles size={28} className="text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground mb-1">مرحباً! أنا Opy</h3>
                <p className="text-sm text-muted-foreground">اكتب أو اضغط الميكروفون للكلام</p>
              </div>
              <div className="flex flex-wrap justify-center gap-2">
                {suggestions.map(s => (
                  <button key={s} onClick={() => setInput(s)}
                    className="px-3 py-1.5 text-xs rounded-full bg-secondary/60 hover:bg-secondary border border-border/40 hover:border-primary/40 text-muted-foreground hover:text-foreground transition-all">
                    {s}
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          <AnimatePresence initial={false}>
            {messages.map(m => (
              <MsgBubble key={m.id} msg={m} onSpeak={speak} speakingId={speakingId} />
            ))}
          </AnimatePresence>

          {streaming && streamText && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="flex gap-3">
              <div className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center ring-2 mt-0.5 bg-primary/10 ring-primary/25 text-primary">
                <Brain size={14} />
              </div>
              <div className="ai-bubble max-w-[85%] rounded-2xl rounded-tl-sm px-4 py-3 text-sm min-w-0" dir={getDir(streamText)}>
                <div className="prose-chat">
                  <ReactMarkdown
                    remarkPlugins={[remarkGfm]}
                    components={{
                      code({ className, children, ...props }: any) {
                        if (/language-/.test(className || "")) return <CodeBlock className={className}>{children}</CodeBlock>
                        return <code className="bg-muted px-1.5 py-0.5 rounded-md text-primary text-[0.8em] font-mono" {...props}>{children}</code>
                      },
                      pre({ children }: any) { return <>{children}</> },
                    }}
                  >{streamText}</ReactMarkdown>
                </div>
                <span className="inline-block w-0.5 h-4 bg-primary cursor-blink ml-0.5 align-middle" />
              </div>
            </motion.div>
          )}

          {streaming && !streamText && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3">
              <div className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center ring-2 mt-0.5 bg-primary/10 ring-primary/25 text-primary">
                <Brain size={14} />
              </div>
              <div className="ai-bubble rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-2">
                <WaveAnim active /> <span className="text-xs text-muted-foreground">Opy يفكر...</span>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* ── input ── */}
      <div className="flex-shrink-0 border-t border-border/50 px-4 py-4 bg-background/95 backdrop-blur-sm">
        <div className="max-w-3xl mx-auto">
          {isTranscribing && (
            <div className="flex items-center gap-2 text-xs text-primary mb-2 animate-pulse">
              <Loader2 size={11} className="animate-spin" /> جاري تحويل الصوت...
            </div>
          )}
          <div className="flex items-end gap-2 p-2 rounded-2xl glass-card input-glow transition-all">
            <button
              onMouseDown={startRec} onMouseUp={stopRec}
              onTouchStart={startRec} onTouchEnd={stopRec}
              disabled={streaming || isTranscribing}
              className={`shrink-0 p-2.5 rounded-xl transition-all select-none disabled:opacity-40
                ${isRecording ? "bg-red-500/20 text-red-400 ring-1 ring-red-500/40 voice-ring-active" : "hover:bg-secondary text-muted-foreground hover:text-primary"}`}
              title="اضغط مع الاستمرار للكلام">
              {isRecording ? <WaveAnim active /> : <Mic size={18} />}
            </button>
            <textarea
              ref={textareaRef} value={input}
              onChange={e => setInput(e.target.value)} onKeyDown={onKey}
              dir={getDir(input)} rows={1}
              placeholder="اكتب رسالتك... أو اضغط الميكروفون للكلام"
              className="flex-1 bg-transparent resize-none outline-none text-sm text-foreground placeholder:text-muted-foreground/50 py-2 px-1 max-h-40 leading-relaxed"
            />
            {streaming ? (
              <button onClick={() => abortRef.current?.abort()}
                className="shrink-0 p-2.5 rounded-xl bg-red-500/20 text-red-400 hover:bg-red-500/30 ring-1 ring-red-500/40 transition-all">
                <StopCircle size={18} />
              </button>
            ) : (
              <button onClick={send} disabled={!input.trim()}
                className="shrink-0 p-2.5 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-30 transition-all shadow-[0_0_14px_-4px_var(--glow-primary)]">
                <Send size={18} />
              </button>
            )}
          </div>
          <p className="text-center text-[10px] text-muted-foreground/40 mt-2">
            Enter لإرسال · Shift+Enter سطر جديد · اضغط الميكروفون للكلام
          </p>
        </div>
      </div>
    </div>
  )
}