import React, { useState } from "react"
import { useSearchMemory } from "@workspace/api-client-react"
import { Search, Loader2, Database, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { motion } from "framer-motion"
import { format } from "date-fns"

export default function ToolMemory() {
  const [query, setQuery] = useState("")
  const searchMemory = useSearchMemory()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (!query.trim()) return
    searchMemory.mutate({ data: { query, limit: 10 } })
  }

  return (
    <div className="h-full overflow-y-auto p-6 md:p-12 custom-scrollbar">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 flex items-center justify-center text-cyan-400 border border-cyan-500/30">
            <Database size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">Neural Memory Search</h1>
            <p className="text-muted-foreground text-sm">Query past conversations and extracted knowledge.</p>
          </div>
        </div>

        <form onSubmit={handleSearch} className="flex gap-4">
          <Input 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search keywords, concepts, or past responses..."
            className="text-lg py-6 shadow-xl bg-card border-primary/30 focus-visible:ring-primary/50"
          />
          <Button type="submit" variant="glow" className="h-[52px] px-8" disabled={!query.trim() || searchMemory.isPending}>
            {searchMemory.isPending ? <Loader2 className="animate-spin" size={24} /> : <Search size={24} />}
          </Button>
        </form>

        <div className="space-y-4 pt-6">
          {searchMemory.isSuccess && searchMemory.data && searchMemory.data.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <Database size={48} className="mx-auto mb-4 opacity-20" />
              <p>No memory fragments found matching this query.</p>
            </div>
          )}

          {searchMemory.isSuccess && searchMemory.data?.map((entry, idx) => (
            <motion.div
              key={entry.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="glass-panel p-6 rounded-2xl relative overflow-hidden group"
            >
              <div className="absolute top-0 left-0 w-1 h-full bg-primary/50 group-hover:bg-primary transition-colors" />
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-2 text-xs font-mono text-primary/80">
                  <Database size={14} />
                  <span>Fragment ID: {entry.id.substring(0,8)}</span>
                  <span className="text-muted-foreground mx-2">•</span>
                  <span>Relevance: {(entry.relevance * 100).toFixed(1)}%</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock size={12} />
                  {format(new Date(entry.createdAt), "MMM d, yyyy HH:mm")}
                </div>
              </div>
              <p className="text-foreground leading-relaxed">"{entry.content}"</p>
              <div className="mt-4 pt-4 border-t border-border/50 text-xs text-muted-foreground flex justify-between">
                <span>Source: {entry.source}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}
