import React, { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  BookMarked, Plus, Trash2, Tag, Loader2, Brain,
  Search, Globe, Link2, RefreshCw, X, CheckCircle2, Sparkles
} from "lucide-react"
import { toast } from "sonner"

const API_BASE = window.location.origin

interface KnowledgeEntry {
  id: string
  title: string
  content: string
  tags: string[]
  source: string
  learnedAt: string
}

type Tab = "list" | "add" | "web"

export default function ToolKnowledge() {
  const [entries, setEntries] = useState<KnowledgeEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState("")
  const [tab, setTab] = useState<Tab>("list")

  /* manual add form */
  const [form, setForm] = useState({ title: "", content: "", tags: "" })
  const [saving, setSaving] = useState(false)

  /* web learn form */
  const [webUrl, setWebUrl] = useState("")
  const [webTopic, setWebTopic] = useState("")
  const [webLoading, setWebLoading] = useState(false)
  const [webResult, setWebResult] = useState<{ count: number; hostname: string } | null>(null)

  const load = async () => {
    setLoading(true)
    try {
      const r = await fetch(`${API_BASE}/api/learn`)
      const d = await r.json()
      setEntries(Array.isArray(d) ? d : [])
    } catch { toast.error("فشل تحميل قاعدة المعرفة") }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  /* ── Save manual entry ── */
  const save = async () => {
    if (!form.content.trim()) { toast.error("المحتوى مطلوب"); return }
    setSaving(true)
    try {
      const r = await fetch(`${API_BASE}/api/learn`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: form.title || form.content.slice(0, 60),
          content: form.content,
          tags: form.tags.split(",").map(t => t.trim()).filter(Boolean),
          source: "manual",
        }),
      })
      if (!r.ok) throw new Error()
      toast.success("✅ تم حفظ المعلومة!")
      setForm({ title: "", content: "", tags: "" })
      setTab("list")
      load()
    } catch { toast.error("فشل الحفظ") }
    finally { setSaving(false) }
  }

  /* ── Learn from website ── */
  const learnFromWeb = async () => {
    let url = webUrl.trim()
    if (!url) { toast.error("أدخل رابط الموقع"); return }
    if (!url.startsWith("http")) url = "https://" + url
    setWebLoading(true); setWebResult(null)
    try {
      const r = await fetch(`${API_BASE}/api/learn/web`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, topic: webTopic || undefined }),
      })
      const d = await r.json()
      if (!r.ok) throw new Error(d.message || d.error)
      setWebResult({ count: d.count, hostname: d.hostname })
      if (d.count > 0) {
        toast.success(`✅ تعلّم Opy ${d.count} معلومة من ${d.hostname}`)
        load()
      } else {
        toast.warning("لم أجد معلومات مفيدة في هذا الموقع")
      }
    } catch (e: any) { toast.error(e?.message || "فشل جلب الموقع") }
    finally { setWebLoading(false) }
  }

  /* ── Delete entry ── */
  const remove = async (id: string) => {
    if (!confirm("حذف هذه المعلومة؟")) return
    try {
      await fetch(`${API_BASE}/api/learn/${id}`, { method: "DELETE" })
      setEntries(p => p.filter(e => e.id !== id))
      toast.success("تم الحذف")
    } catch { toast.error("فشل الحذف") }
  }

  const filtered = entries.filter(e =>
    !filter || e.title.includes(filter) || e.content.includes(filter) || e.tags.some(t => t.includes(filter))
  )

  const TABS = [
    { id: "list" as Tab, label: "القاعدة", icon: BookMarked },
    { id: "add" as Tab, label: "إضافة يدوية", icon: Plus },
    { id: "web" as Tab, label: "تعلم من موقع", icon: Globe },
  ]

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 space-y-5">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center ring-1 ring-primary/20">
              <BookMarked size={20} className="text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">قاعدة المعرفة</h1>
              <p className="text-xs text-muted-foreground">{entries.length} معلومة — تُضاف تلقائياً لسياق Opy</p>
            </div>
          </div>
          <button onClick={load} className="p-2 rounded-xl hover:bg-secondary text-muted-foreground hover:text-foreground transition-all border border-border/40">
            <RefreshCw size={15} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 bg-secondary/40 rounded-xl border border-border/30">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-semibold transition-all
                ${tab === t.id ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"}`}>
              <t.icon size={13} /> {t.label}
            </button>
          ))}
        </div>

        {/* ── Tab: Add manually ── */}
        <AnimatePresence mode="wait">
          {tab === "add" && (
            <motion.div key="add"
              initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
              className="glass-card rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2">
                <Brain size={16} className="text-primary" />
                <span className="font-semibold text-foreground text-sm">معلومة جديدة لـ Opy</span>
              </div>
              <input value={form.title}
                onChange={e => setForm(p => ({ ...p, title: e.target.value }))}
                placeholder="العنوان (اختياري)" dir="auto"
                className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 outline-none border border-border/50 focus:border-primary/50 transition-all" />
              <textarea value={form.content}
                onChange={e => setForm(p => ({ ...p, content: e.target.value }))}
                placeholder="المحتوى — ما تريد أن يتعلمه Opy..." dir="auto" rows={4}
                className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 outline-none border border-border/50 focus:border-primary/50 transition-all resize-none" />
              <input value={form.tags}
                onChange={e => setForm(p => ({ ...p, tags: e.target.value }))}
                placeholder="الوسوم: برمجة, Python, ..." dir="auto"
                className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 outline-none border border-border/50 focus:border-primary/50 transition-all" />
              <div className="flex gap-2">
                <button onClick={save} disabled={saving || !form.content.trim()}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-50 transition-all">
                  {saving ? <Loader2 size={14} className="animate-spin" /> : null} حفظ
                </button>
                <button onClick={() => setTab("list")}
                  className="px-4 py-2 rounded-xl bg-secondary text-muted-foreground text-sm font-medium hover:text-foreground transition-all">
                  إلغاء
                </button>
              </div>
            </motion.div>
          )}

          {/* ── Tab: Learn from web ── */}
          {tab === "web" && (
            <motion.div key="web"
              initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
              className="space-y-4">

              <div className="glass-card rounded-2xl p-5 space-y-4">
                <div className="flex items-center gap-2">
                  <Globe size={16} className="text-primary" />
                  <span className="font-semibold text-foreground text-sm">تعلم من موقع ويب</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  أدخل رابط أي موقع — سيقوم Opy بزيارته واستخراج المعلومات المفيدة تلقائياً وحفظها في قاعدة المعرفة.
                </p>
                <div className="flex gap-2">
                  <div className="flex-1 relative">
                    <Link2 size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground/50" />
                    <input value={webUrl}
                      onChange={e => setWebUrl(e.target.value)}
                      onKeyDown={e => e.key === "Enter" && learnFromWeb()}
                      placeholder="https://example.com/article"
                      dir="ltr"
                      className="w-full bg-secondary/60 rounded-xl pr-9 pl-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 outline-none border border-border/50 focus:border-primary/50 transition-all" />
                  </div>
                  <button onClick={learnFromWeb} disabled={webLoading || !webUrl.trim()}
                    className="px-4 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-40 transition-all flex items-center gap-2 shrink-0">
                    {webLoading ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                    {webLoading ? "جاري..." : "تعلّم"}
                  </button>
                </div>
                <input value={webTopic}
                  onChange={e => setWebTopic(e.target.value)}
                  placeholder="الموضوع المهم (اختياري) — مثال: مكتبات React"
                  dir="auto"
                  className="w-full bg-secondary/60 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 outline-none border border-border/50 focus:border-primary/40 transition-all" />

                {webResult && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                    className={`flex items-center gap-3 p-3 rounded-xl border
                      ${webResult.count > 0 ? "bg-primary/10 border-primary/30 text-primary" : "bg-orange-500/10 border-orange-500/30 text-orange-400"}`}>
                    <CheckCircle2 size={16} />
                    <span className="text-sm font-medium">
                      {webResult.count > 0
                        ? `تعلّم ${webResult.count} معلومة من ${webResult.hostname}`
                        : `لم يجد Opy معلومات مفيدة في ${webResult.hostname}`}
                    </span>
                  </motion.div>
                )}

                {/* preset sources */}
                <div>
                  <p className="text-[11px] text-muted-foreground/60 mb-2 font-semibold uppercase tracking-wider">مصادر مقترحة</p>
                  <div className="flex flex-wrap gap-2">
                    {[
                      ["https://ar.wikipedia.org/wiki/ذكاء_اصطناعي", "ويكيبيديا - AI"],
                      ["https://developer.mozilla.org/ar/docs/Web/JavaScript", "MDN عربي"],
                      ["https://docs.python.org/ar/3/", "Python Docs"],
                    ].map(([url, label]) => (
                      <button key={url} onClick={() => setWebUrl(url)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-secondary/60 hover:bg-secondary border border-border/40 hover:border-primary/30 text-xs text-muted-foreground hover:text-foreground transition-all">
                        <Globe size={11} className="text-primary" /> {label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* ── Tab: List ── */}
          {tab === "list" && (
            <motion.div key="list"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="space-y-4">
              {entries.length > 0 && (
                <div className="relative">
                  <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground/50" />
                  <input value={filter} onChange={e => setFilter(e.target.value)}
                    placeholder="بحث في قاعدة المعرفة..." dir="rtl"
                    className="w-full bg-secondary/40 rounded-xl pr-9 pl-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 outline-none border border-border/40 focus:border-primary/40 transition-all" />
                </div>
              )}

              {loading ? (
                <div className="flex items-center justify-center py-16">
                  <Loader2 size={24} className="animate-spin text-primary/50" />
                </div>
              ) : filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-primary/5 flex items-center justify-center ring-1 ring-border">
                    <BookMarked size={24} className="text-muted-foreground/30" />
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm">
                      {filter ? "لا نتائج تطابق البحث" : "لا توجد معلومات بعد"}
                    </p>
                    {!filter && (
                      <div className="flex gap-2 justify-center mt-3">
                        <button onClick={() => setTab("add")}
                          className="px-3 py-1.5 text-xs rounded-full bg-secondary hover:bg-secondary/80 text-muted-foreground hover:text-foreground border border-border/40 transition-all">
                          إضافة يدوية
                        </button>
                        <button onClick={() => setTab("web")}
                          className="px-3 py-1.5 text-xs rounded-full bg-primary/10 hover:bg-primary/20 text-primary border border-primary/30 transition-all">
                          تعلم من موقع
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <AnimatePresence initial={false}>
                    {filtered.map(e => (
                      <motion.div key={e.id}
                        initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -20 }}
                        className="glass-card rounded-2xl p-4 group hover:border-primary/20 transition-all">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0 flex-1">
                            <h4 className="font-semibold text-foreground text-sm mb-1.5" dir="auto">{e.title}</h4>
                            <p className="text-muted-foreground text-xs leading-relaxed line-clamp-3" dir="auto">{e.content}</p>
                            <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
                              {e.tags?.map(t => (
                                <span key={t} className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[11px] font-medium">
                                  <Tag size={9} /> {t}
                                </span>
                              ))}
                              {e.source?.startsWith("http") ? (
                                <a href={e.source} target="_blank" rel="noreferrer"
                                  className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-secondary text-muted-foreground text-[11px] hover:text-primary transition-colors">
                                  <Globe size={9} />
                                  {(() => { try { return new URL(e.source).hostname; } catch { return e.source.slice(0, 20); } })()}
                                </a>
                              ) : (
                                <span className="px-2 py-0.5 rounded-full bg-secondary text-muted-foreground text-[11px]">{e.source}</span>
                              )}
                            </div>
                          </div>
                          <button onClick={() => remove(e.id)}
                            className="shrink-0 p-1.5 rounded-lg opacity-0 group-hover:opacity-100 hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-all">
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
