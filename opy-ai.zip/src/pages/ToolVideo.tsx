import React, { useState } from "react"
import { useGenerateVideo } from "@workspace/api-client-react"
import { Video, Loader2, PlaySquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"

export default function ToolVideo() {
  const [description, setDescription] = useState("")
  const [frames, setFrames] = useState(30)
  
  const generateVideo = useGenerateVideo()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!description.trim()) return
    generateVideo.mutate({ data: { description, frames, fps: 10 } })
  }

  return (
    <div className="h-full overflow-y-auto p-6 md:p-12 custom-scrollbar">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 flex items-center justify-center text-indigo-400 border border-indigo-500/30">
            <Video size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">Video Synthesis</h1>
            <p className="text-muted-foreground text-sm">Sequential frame rendering built internally.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-5 space-y-6">
            <form onSubmit={handleSubmit} className="space-y-6 glass-panel p-6 rounded-2xl">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-foreground">Motion Description</label>
                <Textarea 
                  placeholder="Describe the movement and shapes..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="min-h-[120px]"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-foreground">Frames (Duration)</label>
                <Input 
                  type="number" 
                  value={frames}
                  onChange={(e) => setFrames(parseInt(e.target.value) || 30)}
                  min={10} max={100}
                />
                <p className="text-xs text-muted-foreground text-right">{frames} frames @ 10fps = {(frames/10).toFixed(1)}s</p>
              </div>

              <Button type="submit" className="w-full bg-indigo-500 hover:bg-indigo-600 text-white" disabled={!description.trim() || generateVideo.isPending}>
                {generateVideo.isPending ? (
                  <><Loader2 className="mr-2 animate-spin" size={18} /> Compiling Frames...</>
                ) : (
                  <><PlaySquare className="mr-2" size={18} /> Render Sequence</>
                )}
              </Button>
            </form>
          </div>

          <div className="lg:col-span-7">
            <div className="glass-panel p-2 rounded-2xl aspect-video flex flex-col items-center justify-center relative overflow-hidden bg-background">
              {generateVideo.isPending ? (
                <div className="flex flex-col items-center gap-4 text-indigo-400">
                  <Loader2 size={48} className="animate-spin" />
                  <span className="font-mono text-sm uppercase tracking-widest animate-pulse">Generating Matrix Sequence...</span>
                </div>
              ) : generateVideo.isSuccess && generateVideo.data ? (
                <div className="text-center space-y-4">
                  <div className="w-20 h-20 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-4 border border-emerald-500/30">
                    <Video size={32} />
                  </div>
                  <h3 className="text-xl font-bold">Sequence Rendered</h3>
                  <p className="text-muted-foreground">ID: {generateVideo.data.id}</p>
                  <p className="text-sm font-mono text-emerald-400">Status: {generateVideo.data.status}</p>
                  <Button variant="outline" className="mt-4 border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/10">Play Sequence</Button>
                </div>
              ) : (
                <div className="text-muted-foreground flex flex-col items-center gap-2">
                  <Video size={48} className="opacity-20" />
                  <span className="text-sm font-medium">Player standby</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
