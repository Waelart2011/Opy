/**
 * Self-Modification page — Opy reads and rewrites its own source files.
 */
import React, { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Code2, File, Save, Eye, ChevronRight, Loader2, AlertTriangle, Sparkles, RefreshCw } from "lucide-react"
import { toast } from "sonner"

const API_BASE = window.location.origin

interface FileMeta { path: string; lines?: number }

export default function ToolSelf() {
  const [files, setFiles] = useState<string[]>([])
  const [selectedFile, setSelectedFile] = useState("")
  const [fileContent, setFileContent] = useState("")
  const [instruction, setInstruction] = useState("")
  const [preview, setPreview] = useState<{ original: string; modified: string } | null>(null)
  const [loading, setLoading] = useState(false)
  const [filesLoading, setFilesLoading] = useState(true)
  const [applying, setApplying] = useState(false)

  const loadFiles = async () => {
    setFilesLoading(true)
    try {
      const r = await fetch(`${API_BASE}/api/self/files`)
      const d = await r.json()
      setFiles(d.files || [])
    } catch { toast.error("فشل تحميل الملفات") }
    finally { setFilesLoading(false) }
  }

  const readFile = async (path: string) => {
    setSelectedFile(path); setPreview(null); setInstruction("")
    try {
      const r = await fetch(`${API_BASE}/api/self/read?path=${encodeURIComponent(path)}`)
      const d = await r.json()
      setFileContent(d.content || "")
    } catch { toast.error("فشل قراءة الملف") }
  }

  useEffect(() => { loadFiles() }, [])

  const generatePreview = async () => {
    if (!selectedFile || !instruction.trim()) {
      toast.error("اختر ملفاً واكتب تعليمات التعديل")
      return
    }
    setLoading(true); setPreview(null)
    try {
      const r = await fetch(`${API_BASE}/api/self/modify`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: selectedFile, instruction, preview: true }),
      })
      const d = await r.json()
      if (d.error) throw new Error(d.error)
      setPreview({ original: d.original || fileContent, modified: d.modified })
      toast.success("✓ المعاينة جاهزة — راجع التغييرات قبل التطبيق")
    } catch (e: any) { toast.error(e.message || "فشل التوليد") }
    finally { setLoading(false) }
  }

  const applyChanges = async () => {
    if (!preview || !selectedFile) return
    if (!confirm("⚠️ هل أنت متأكد من تطبيق التعديلات على الملف؟ سيتم حفظه فوراً.")) return
    setApplying(true)
    try {
      const r = await fetch(`${API_BASE}/api/self/modify`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: selectedFile, instruction, preview: false }),
      })
      const d = await r.json()
      if (d.error) throw new Error(d.error)
      toast.success(`✅ تم تطبيق التعديلات على ${selectedFile}`)
      setFileContent(preview.modified)
      setPreview(null); setInstruction("")
      toast.info("🔄 أعد تشغيل التطبيق لتفعيل التغييرات")
    } catch (e: any) { toast.error(e.message || "فشل التطبيق") }
    finally { setApplying(false) }
  }

  const groups = files.reduce<Record<string, string[]>>((acc, f) => {
    const parts = f.split("/")
    const group = parts.slice(0, 3).join("/")
    if (!acc[group]) acc[group] = []
    acc[group].push(f)
    return acc
  }, {})

  return (
    <div className="h-full flex overflow-hidden">
      {/* ── File tree ── */}
      <div className="w-64 shrink-0 border-r border-border/40 flex flex-col bg-card/50">
        <div className="p-4 border-b border-border/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Code2 size={16} className="text-primary" />
            <span className="text-sm font-bold text-foreground">ملفات Opy</span>
          </div>
          <button onClick={loadFiles} className="p-1 hover:bg-secondary rounded-lg text-muted-foreground hover:text-foreground transition-all">
            <RefreshCw size={13} />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {filesLoading ? (
            <div className="flex justify-center py-8"><Loader2 size={18} className="animate-spin text-primary/50" /></div>
          ) : (
            Object.entries(groups).map(([group, groupFiles]) => (
              <div key={group} className="mb-3">
                <p className="px-2 py-1 text-[10px] font-bold text-muted-foreground/50 uppercase tracking-wider">
                  {group.split("/").pop()}
                </p>
                {groupFiles.map(f => (
                  <button key={f} onClick={() => readFile(f)}
                    className={`w-full text-left flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs transition-all
                      ${selectedFile === f ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground"}`}>
                    <File size={11} className="shrink-0" />
                    <span className="truncate">{f.split("/").pop()}</span>
                  </button>
                ))}
              </div>
            ))
          )}
        </div>
      </div>

      {/* ── Editor ── */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {!selectedFile ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4 text-center p-8">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center ring-1 ring-primary/20">
              <Sparkles size={28} className="text-primary" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-foreground mb-2">تعديل ذاتي — Opy يُطوّر نفسه</h3>
              <p className="text-sm text-muted-foreground max-w-md">
                اختر ملفاً من القائمة الجانبية، ثم أخبر Opy بما تريد تغييره.
                سيقوم بتوليد التعديلات باستخدام الذكاء الاصطناعي.
              </p>
            </div>
            <div className="glass-card rounded-xl p-4 text-right max-w-sm w-full" dir="rtl">
              <p className="text-xs text-muted-foreground font-semibold mb-2">أمثلة على التعليمات:</p>
              {["أضف ميزة الترجمة التلقائية", "احذف أزرار الفيديو من الواجهة", "أضف تأثير صوتي عند الإرسال"].map(e => (
                <div key={e} className="flex items-center gap-2 py-1 text-xs text-muted-foreground">
                  <ChevronRight size={10} className="text-primary" /> {e}
                </div>
              ))}
            </div>
          </div>
        ) : (
          <>
            {/* file header */}
            <div className="flex-shrink-0 p-4 border-b border-border/30 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <File size={15} className="text-primary" />
                <span className="text-sm font-mono text-foreground">{selectedFile}</span>
                <span className="text-xs text-muted-foreground bg-secondary px-2 py-0.5 rounded-full">
                  {fileContent.split("\n").length} سطر
                </span>
              </div>
            </div>

            {/* instruction input */}
            <div className="flex-shrink-0 p-4 border-b border-border/20 bg-card/30">
              <div className="flex gap-2">
                <textarea
                  value={instruction}
                  onChange={e => setInstruction(e.target.value)}
                  placeholder="اكتب تعليمات التعديل... مثال: أضف زر للنسخ في الزاوية العلوية"
                  dir="auto" rows={2}
                  className="flex-1 bg-secondary/60 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 outline-none border border-border/40 focus:border-primary/50 resize-none transition-all"
                />
                <div className="flex flex-col gap-2">
                  <button onClick={generatePreview} disabled={loading || !instruction.trim()}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary/10 text-primary border border-primary/30 text-sm font-semibold hover:bg-primary/20 disabled:opacity-40 transition-all">
                    {loading ? <Loader2 size={14} className="animate-spin" /> : <Eye size={14} />}
                    معاينة
                  </button>
                  {preview && (
                    <button onClick={applyChanges} disabled={applying}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-50 transition-all">
                      {applying ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                      تطبيق
                    </button>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 mt-2">
                <AlertTriangle size={12} className="text-orange-400 shrink-0" />
                <p className="text-[11px] text-muted-foreground/70">
                  راجع المعاينة دائماً قبل التطبيق · التغييرات ستُحفظ مباشرة على الملف
                </p>
              </div>
            </div>

            {/* content area */}
            <div className="flex-1 overflow-y-auto">
              {preview ? (
                <div className="p-4 grid grid-cols-2 gap-4 h-full">
                  <div>
                    <p className="text-xs font-bold text-muted-foreground mb-2 uppercase tracking-wider">الأصلي</p>
                    <pre className="text-xs font-mono bg-muted/20 p-4 rounded-xl overflow-auto h-full border border-border/30 leading-relaxed whitespace-pre-wrap">
                      {preview.original}
                    </pre>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-primary mb-2 uppercase tracking-wider">المعدّل</p>
                    <pre className="text-xs font-mono bg-primary/5 p-4 rounded-xl overflow-auto h-full border border-primary/20 leading-relaxed whitespace-pre-wrap">
                      {preview.modified}
                    </pre>
                  </div>
                </div>
              ) : (
                <pre className="text-xs font-mono p-4 text-muted-foreground leading-relaxed whitespace-pre-wrap overflow-auto h-full">
                  {fileContent || <span className="italic opacity-50">جاري التحميل...</span>}
                </pre>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
