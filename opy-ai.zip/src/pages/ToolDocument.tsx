import React, { useState } from "react"
import { useGenerateDocument } from "@workspace/api-client-react"
import { FileText, Loader2, Download, FileCode } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"

export default function ToolDocument() {
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [format, setFormat] = useState<"txt" | "markdown" | "html">("markdown")
  
  const generateDoc = useGenerateDocument()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim() || !content.trim()) return
    generateDoc.mutate({ data: { title, content, format } })
  }

  return (
    <div className="h-full overflow-y-auto p-6 md:p-12 custom-scrollbar">
      <div className="max-w-5xl mx-auto space-y-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-orange-500/20 flex items-center justify-center text-orange-400 border border-orange-500/30">
            <FileText size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">Document Creator</h1>
            <p className="text-muted-foreground text-sm">Create and format text files, docs, and notes.</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 glass-panel p-6 rounded-2xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-2">
              <label className="text-sm font-semibold text-foreground">Document Title</label>
              <Input 
                placeholder="e.g. Analysis_Report_v1"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-foreground">Format</label>
              <div className="flex gap-2 bg-background p-1 rounded-lg border border-border">
                {(["markdown", "txt", "html"] as const).map((f) => (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setFormat(f)}
                    className={`flex-1 py-1.5 rounded-md text-xs font-bold uppercase transition-all ${format === f ? 'bg-orange-500 text-white shadow-md' : 'text-muted-foreground hover:bg-secondary'}`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-foreground">Content Draft</label>
            <Textarea 
              placeholder="Start typing your content or instructions for Opy..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-[300px] font-mono"
            />
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-border/50">
            {generateDoc.isSuccess && generateDoc.data ? (
              <div className="flex items-center gap-3 text-emerald-400 text-sm font-medium">
                <FileCode size={18} />
                <span>Document saved: {generateDoc.data.title}.{generateDoc.data.format}</span>
              </div>
            ) : <div/>}
            
            <Button type="submit" className="bg-orange-500 hover:bg-orange-600 text-white" disabled={!title.trim() || !content.trim() || generateDoc.isPending}>
              {generateDoc.isPending ? (
                <><Loader2 className="mr-2 animate-spin" size={18} /> Compiling...</>
              ) : (
                <><Download className="mr-2" size={18} /> Export Document</>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
