import React from "react"
import { motion } from "framer-motion"
import { Shield, Brain, Sparkles, Code2, Mic, BookMarked, Image as ImageIcon, Video } from "lucide-react"
import { useCreateChatSession } from "@workspace/api-client-react"
import { useQueryClient } from "@tanstack/react-query"
import { useLocation } from "wouter"

export default function Welcome() {
  const queryClient = useQueryClient()
  const [, setLocation] = useLocation()

  const createSession = useCreateChatSession({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: ["/api/chat/sessions"] })
        setLocation(`/session/${data.id}`)
      }
    }
  })

  const features = [
    { icon: Brain, label: "تحليل النصوص", desc: "فهم المعنى والبحث في الذاكرة", color: "text-primary", bg: "bg-primary/10" },
    { icon: ImageIcon, label: "توليد الصور", desc: "إنشاء صور بالذكاء الاصطناعي", color: "text-violet-400", bg: "bg-violet-500/10" },
    { icon: Video, label: "إنشاء الفيديو", desc: "توليد مقاطع فيديو داخلية", color: "text-orange-400", bg: "bg-orange-500/10" },
    { icon: Code2, label: "كتابة الكود", desc: "جميع لغات البرمجة", color: "text-emerald-400", bg: "bg-emerald-500/10" },
    { icon: BookMarked, label: "قاعدة المعرفة", desc: "يتعلم ويحفظ ما تعلمه", color: "text-cyan-400", bg: "bg-cyan-500/10" },
    { icon: Mic, label: "صوت Jarvis", desc: "تحدث وأصغِ بصوت واقعي", color: "text-pink-400", bg: "bg-pink-500/10" },
  ]

  const badges = [
    { icon: Shield, label: "غير متصل افتراضياً", color: "text-emerald-400" },
    { icon: Code2, label: "لا إجراءات تلقائية", color: "text-primary" },
    { icon: Sparkles, label: "تحكم كامل", color: "text-orange-400" },
  ]

  return (
    <div className="h-full w-full overflow-y-auto flex flex-col items-center justify-center p-6 md:p-10">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-3xl w-full text-center space-y-10"
      >
        {/* Logo */}
        <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ delay: 0.1 }}
          className="mx-auto w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/90 to-accent/50 p-0.5 shadow-[0_0_50px_-10px_var(--glow-primary)]">
          <div className="w-full h-full bg-background rounded-[14px] flex items-center justify-center">
            <Brain size={36} className="text-primary" />
          </div>
        </motion.div>

        {/* Title */}
        <div>
          <h1 className="text-5xl md:text-6xl font-bold text-foreground tracking-tight mb-3">
            مرحباً في <span className="text-gradient">Opy</span>
          </h1>
          <p className="text-base md:text-lg text-muted-foreground max-w-xl mx-auto leading-relaxed">
            مساعدك الشخصي المتقدم، مثل Jarvis من Iron Man.
            يعمل تحت سيطرتك الكاملة، يتعلم، ويتذكر.
          </p>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap justify-center gap-3">
          {badges.map(b => (
            <div key={b.label} className="glass-card px-4 py-2 rounded-full flex items-center gap-2 text-sm font-medium">
              <b.icon size={15} className={b.color} />
              <span>{b.label}</span>
            </div>
          ))}
        </div>

        {/* Feature grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-right" dir="rtl">
          {features.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 + i * 0.07 }}
              className="feature-card glass-card rounded-2xl p-4 cursor-default"
            >
              <div className={`w-10 h-10 rounded-xl ${f.bg} flex items-center justify-center mb-3`}>
                <f.icon size={20} className={f.color} />
              </div>
              <h3 className="font-bold text-sm text-foreground mb-1">{f.label}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
          <button
            onClick={() => createSession.mutate({ data: { title: "محادثة جديدة" } })}
            className="inline-flex items-center gap-3 px-8 py-3.5 rounded-2xl bg-primary text-primary-foreground font-bold text-base hover:bg-primary/90 transition-all shadow-[0_0_30px_-8px_var(--glow-primary)] hover:shadow-[0_0_40px_-6px_var(--glow-primary)]"
          >
            <Sparkles size={20} /> ابدأ المحادثة
          </button>
        </motion.div>
      </motion.div>
    </div>
  )
}
